from .mapper import router as mapper_router
from .schemer import router as schemer_router
from .clientes import router as cat_clientes_router
 
routers = [
    #mapper_router,
    #schemer_router,
    cat_clientes_router
]
