from fastapi import APIRouter
import os
import inspect
from models import m_appBli_ as models_module  #Descomentar y cambiar el nombre del archivo con tus modelos.
from core.utils import APIResponse
from core import pydantic_util

router = APIRouter(prefix="/Schemer")

schema_dir = "schemas"

@router.get("/", tags=["System"])
def Schemer():
    try:
        os.makedirs(schema_dir, exist_ok=True)

        for name, obj in inspect.getmembers(models_module):
            if inspect.isclass(obj) and hasattr(obj, "__table__"):
                pydantic_util.write_schema_file(obj)

        # schemas/__init__.py
        init_file = os.path.join(schema_dir, "__init__.py")
        with open(init_file, "w") as f:
            for name, obj in inspect.getmembers(models_module):
                if inspect.isclass(obj) and hasattr(obj, "__table__"):
                    f.write(f"from .{name.lower()} import {name}Base, {name}Create, {name}Update, {name}Read\n")

        return APIResponse.success(status_code=200, message="Esquemas creados correctamente.") 
        
    except Exception as e:
        return APIResponse.error(status_code=500, errors=f"Excepción: {str(e)}")
