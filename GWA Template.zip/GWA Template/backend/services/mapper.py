from fastapi import APIRouter, HTTPException
from models.db import Connection
from urllib.parse import urlparse
import subprocess, os

router = APIRouter(prefix="/Mapper")

@router.get("/", tags=["System"])
async def DBmapper():

    try:
        url_db = Connection.SQLALCHEMY_DATABASE_URL
        parsed_url = urlparse(url_db)
        db_name = parsed_url.path.lstrip("/")

        if not db_name:
            raise HTTPException(status_code=400, detail="No se pudo extraer el nombre de la base de datos")

        base_dir = os.path.dirname(os.path.abspath(__file__))
        data_path = os.path.dirname(base_dir)
        models_dir = os.path.join(data_path, "models")

        os.makedirs(models_dir, exist_ok=True)

        output_filename = f"m_{db_name}.py"
        output_path = os.path.join(models_dir, output_filename)

        cmd = ["sqlacodegen", url_db, "--schema", "dbo" ]

        result = subprocess.run(
            cmd,
            cwd=models_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        if result.returncode != 0:
            raise HTTPException(
                status_code=400,
                detail=f"Error generando modelos: {result.stderr}"
            )

        # Guardar archivo manualmente
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(result.stdout)

        return {
            "status": "success",
            "message": f"Modelos generados correctamente",
            "path": output_path
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
