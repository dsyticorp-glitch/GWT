from fastapi import APIRouter, Depends                                                                                                  
from fastapi.encoders import jsonable_encoder #Para convertir los objetos Pydantic en datos JSON serializables.                         
from sqlalchemy.orm import Session                                                                                                      
from typing import List                                                                                                                 
from models import m_appBli_  # Modelo de la base de datos                                                                              
from models.db import Connection  # Función para obtener la sesión de DB                                                                    
from schemas import * # Importa los esquemas Pydantic                                                                              
from services.crud import CRUDBase #Los Servicios de crud                                                                          
from core.utils import APIResponse                                                                                                      
from fastapi import APIRouter

crud_Accounts = CRUDBase[m_appBli_.Accounts, AccountsCreate, AccountsUpdate, AccountsRead](model=m_appBli_.Accounts,read_schema=AccountsRead, pk_field="idAccount")

router = APIRouter(prefix="/Clientes")

@router.get("/", tags=["Catalogos"])
async def traer_clientes():
    try:
        final_data=[]
        with Connection.SessionLocal() as db:
            Accounts = crud_Accounts.get_all(db=db, skip=1, limit=100)

            if Accounts:
                for row in Accounts:                                   
                    final_data.append({
                        'id': row.idAccount, 
                        'name': row.name
                    })
                
                return APIResponse.success(status_code=200, data=final_data)
            else:
                return APIResponse.error(status_code=404, errors="No se encontraron registros.")
              
    except Exception as e:
        return APIResponse.error(status_code=500, errors=f"Excepción: {str(e)}")
