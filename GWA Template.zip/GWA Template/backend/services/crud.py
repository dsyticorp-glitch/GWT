from typing import TypeVar, Generic, Type, Optional, List, Union, Tuple, Any, Dict
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy.sql.elements import BinaryExpression
from sqlalchemy.orm.attributes import InstrumentedAttribute
from sqlalchemy.dialects import mssql
from sqlalchemy.engine.row import Row

ModelType = TypeVar("ModelType")
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)
ReadSchemaType = TypeVar("ReadSchemaType", bound=BaseModel)

class CRUDBase(Generic[ModelType, CreateSchemaType, UpdateSchemaType, ReadSchemaType]):
    def __init__(
        self,
        model: Type[ModelType],
        read_schema: Type[ReadSchemaType],
        pk_field: str = "id"
    ):
        self.model = model
        self.read_schema = read_schema
        self.pk_field = pk_field  # nombre del campo PK 
    #Crea un nuevo registro.
    def create(self, db: Session, obj_in: CreateSchemaType) -> ReadSchemaType:
        query = self.model(**obj_in.model_dump())
        db.add(query)
        return self.read_schema.model_validate(query)
    
    #Modifica un registro.
    def update(self, db: Session, id_value: int, obj_in: UpdateSchemaType) -> Optional[ReadSchemaType]:
        query = db.query(self.model).filter(getattr(self.model, self.pk_field) == id_value).first()
        if not query:
            return None

        obj_data = obj_in.model_dump(exclude_unset=True)
        for field, value in obj_data.items():
            setattr(query, field, value)

        db.add(query)
        return self.read_schema.model_validate(query)
    
    #Elimina un registro.
    def delete(self, db: Session, id_value: int) -> bool:
        query = db.query(self.model).filter(
            getattr(self.model, self.pk_field) == id_value
        ).first()
        if not query:
            return False
        db.delete(query)
        return True
    
    #Trae el primer registro de una consulta a partir de una llave primaria.
    def get_by_id(self, db: Session, id_value: int, printSQL: bool = False) -> Optional[ReadSchemaType]:
        query = db.query(self.model).filter( getattr(self.model, self.pk_field) == id_value)
        
        if printSQL: #Imprime query SQL           
            print(query.statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))
        
        result = query.first()
        return self.read_schema.model_validate(result) if result else None

    #Trae el primer registro de una consulta a partir de una llave primaria compuesta.
    def get_by_composite_id(self,db: Session,printSQL: bool = False,**key_values: Any) -> Optional[Any]:
        
        # Extraer claves primarias del modelo
        primary_keys = [col.name for col in self.model.__mapper__.primary_key]

        # Verificar campos faltantes
        missing_keys = [key for key in primary_keys if key not in key_values]
        if missing_keys:
            raise ValueError(f"Faltan llaves primarias requeridas: {missing_keys}")

        # Verificar campos adicionales no permitidos
        extra_keys = [key for key in key_values if key not in primary_keys]
        if extra_keys:
            raise ValueError(f"Campos no válidos para búsqueda por llave compuesta: {extra_keys}")

        # Construcción de la consulta
        query = db.query(self.model)
        for key in primary_keys:
            query = query.filter(getattr(self.model, key) == key_values[key])

        # Imprimir SQL si se solicita
        if printSQL:
            print(query.statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))
        return query.first()

    #Trae el primer registro de una consulta a partir de un campo (puedes utilizar LIKE) configurado para llaves compuestas.
    def get_by_field(
        self,
        db: Session,
        field: str,
        value: Any,
        use_like: bool = False,
        printSQL: bool = False
    ) -> Optional[ReadSchemaType]:
        try:
            # Verifica que el campo exista en el modelo
            column = getattr(self.model, field)
        except AttributeError:
            raise ValueError(f"El campo '{field}' no existe en el modelo {self.model.__name__}")

        # Armar la consulta
        if use_like:
            query = db.query(self.model).filter(column.like(f"%{value}%"))
        else:
            query = db.query(self.model).filter(column == value)

        # SQL Debug (SQL Server dialect)
        if printSQL:
            from sqlalchemy.dialects import mssql
            print(query.statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))

        # Ejecutar
        result = query.first()

        # Validar con Pydantic si hay resultado
        return self.read_schema.model_validate(result) if result else None

#Trae todos los registros de una consulta a partir de varios campos (puedes utilizar LIKE) configurado para llaves compuestas.
    def get_by_fields(
        self,
        db: Session,
        filters: Dict[str, Any],
        like_fields: Optional[List[str]] = None,
        skip: int = 0,
        limit: int = 100,
        order_by: Optional[List[Any]] = None,
        printSQL: bool = False
    ) -> List[ReadSchemaType]:
        query = db.query(self.model)

        like_fields = like_fields or []

        # Aplicar filtros
        for field, value in filters.items():
            try:
                column = getattr(self.model, field)
            except AttributeError:
                raise ValueError(f"El campo '{field}' no existe en el modelo {self.model.__name__}")
            
            if field in like_fields and isinstance(value, str):
                query = query.filter(column.like(f"%{value}%"))
            else:
                query = query.filter(column == value)

        # Ordenamiento
        final_order_by = []

        if order_by:
            if not isinstance(order_by, (list, tuple)):
                order_by = [order_by]
            final_order_by = order_by
        else:
            if isinstance(self.pk_field, str):
                final_order_by = [getattr(self.model, self.pk_field).asc()]
            elif isinstance(self.pk_field, (list, tuple)):
                final_order_by = [getattr(self.model, f).asc() for f in self.pk_field]

        for clause in final_order_by:
            query = query.order_by(clause)

        # Paginación
        query = query.offset(skip).limit(limit)

        # SQL Debug
        if printSQL:
            print(query.statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))

        results = query.all()
        return [self.read_schema.model_validate(obj) for obj in results]
        
    
    #Trae todos los registros de una tabla, configurado para llaves compuestas.
    def get_all(
        self,
        db: Session,
        skip: int,
        limit: int,
        order_by: Optional[Any] = None,
        printSQL: bool = False
    ) -> List[ReadSchemaType]:
        
        query = db.query(self.model)

        # --- Configuración del ORDER BY ---
        final_order_by = []

        # Si el usuario especifica campos de ordenamiento
        if order_by:
            # Asegura que sea lista o tupla
            if not isinstance(order_by, (list, tuple)):
                order_by = [order_by]
            final_order_by = order_by

        # Si no se especificó `order_by`, usar la llave primaria como respaldo
        else:
            if isinstance(self.pk_field, str):
                final_order_by = [getattr(self.model, self.pk_field).asc()]
            elif isinstance(self.pk_field, (list, tuple)):
                final_order_by = [getattr(self.model, field).asc() for field in self.pk_field]
            else:
                raise TypeError("self.pk_field debe ser un string o una lista de strings.")

        # Aplicar ORDER BY
        for clause in final_order_by:
            query = query.order_by(clause)

        #Aplicar paginación
        query = query.offset(skip).limit(limit)

        #Imprime query SQL
        if printSQL:
            from sqlalchemy.dialects import mssql
            print(query.statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))

        # --- Ejecutar y convertir a Pydantic ---
        result = query.all()
        return [self.read_schema.model_validate(obj) for obj in result]

            
    def get_all_filter(
        self,
        db: Session,
        filters: BaseModel,
        skip: int,
        limit: int,
        order_by: Optional[Any] = None,
        printSQL: bool = False
    ) -> List[ReadSchemaType]:
        query = db.query(self.model)

        # 🔍 Aplicar filtros
        filter_data = filters.model_dump(exclude_none=True)
        for field_name, value in filter_data.items():
            column = getattr(self.model, field_name, None)
            if column is not None:
                query = query.filter(column == value)

        # ORDER BY obligatorio para MSSQL
        if order_by is None:
            order_by = [getattr(self.model, self.pk_field).asc()]
        elif not isinstance(order_by, (list, tuple)):
            order_by = [order_by]
        elif not order_by:
            order_by = [getattr(self.model, self.pk_field).asc()]

        for clause in order_by:
            query = query.order_by(clause)

        objs = query.offset(skip).limit(limit)
        
        if printSQL:#Imprimiendo  la query SQL
            print(objs.statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))
   
        result = objs.all()
        return [self.read_schema.model_validate(obj) for obj in result]
    
    #Trae todos los registros de una consulta con Joins y filtros, configurado para llaves compuestas.
    def get_with_joins(
        self,
        db: Session,
        select_entities: Optional[List[Any]] = None,
        join_models: Optional[List[Any]] = None,
        join_conditions: Optional[List[BinaryExpression]] = None,
        join_types: Optional[List[str]] = None,
        filters: Optional[List[BinaryExpression]] = None,
        order_by: Optional[List[InstrumentedAttribute]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        pydantic_schemas: Optional[List[Type[BaseModel]]] = None,
        printSQL: bool = False
    ) -> Union[List[Any], List[Tuple[Any, ...]]]:
        
        if select_entities is None:
            select_entities = [self.model]

        query = db.query(*select_entities)

        if join_models and join_conditions:
            for i, join_model in enumerate(join_models):
                condition = join_conditions[i]
                join_type = join_types[i] if join_types and i < len(join_types) else "inner"

                if join_type == "left":
                    query = query.outerjoin(join_model, condition)
                else:
                    query = query.join(join_model, condition)

        if filters:
            for condition in filters:
                query = query.filter(condition)

        if order_by:
            for order in order_by:
                query = query.order_by(order)

        if limit:
            query = query.limit(limit)

        if offset:
            query = query.offset(offset)

        if printSQL:
            compiled_sql = query.statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True})
            print(str(compiled_sql))
            
        results = query.all()

        if not pydantic_schemas:
            return results

        serialized = []
        for row in results:
            if isinstance(row, Row):
                row = tuple(row._mapping.values())

            if isinstance(row, tuple):
                item = tuple(
                    schema.model_validate(model, from_attributes=True) if model is not None else None
                    for model, schema in zip(row, pydantic_schemas)
                )
            else:
                item = pydantic_schemas[0].model_validate(row, from_attributes=True)
            serialized.append(item)

        return serialized

