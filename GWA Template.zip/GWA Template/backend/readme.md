1) Crear un entorno virtual:
    python3 -m venv venv
    python -m venv venv

2) Activar el entorno virtual:
    .\venv\Scripts\activate       

3) Actualizar el pip
    python.exe -m pip install --upgrade pip

4) Instalar las librerias(dependencias) del archivo requirements.txt
    pip install -r requirements.txt
    
5) Ejecutar la app
    uvicorn main:app --reload

6) Creacion de Módelos:
    Ya en despliegue la app,  ingresa al sitio Web y ejecutar el API 'Mapper' quien se encargara de crear los modelos del proyecto de SQL Alchemy.

    Los modelos creados viviran en la carpeta 'models' y el nombre inicia con 'm_' seguida del nombre de tu DB. 

    Ejemplo: si la base de datos de tu proyecto se llama 'mxproyecto' el archivo de los modelos sera nombrado como 'm_mxproyecto.py'.

7) Esquemas
    Def: Los esquemas Pydantic, son esquemas que nos ayudan a validar los datos entrantes, convierte los tipos cuando es necesario y proporciona mensajes de error claros cuando falla la validación.

    7.1.- De tu proyecto debes abrir el archivo schemer.py que se encuentra en la carpeta 'services' y en la linea 4 debes descomentar la linea y cambiar el nombre del archivo al que hace referencia, por el mombre del archivo creado en en el anterio paso.

    7.2.- Guarda y refresca el proyecto, posterior ejecuta el servicio de 'Schemer' y se crearan los esquemas de pydantic en la carpeta de 'schemas' para que puedas utilizarlos en tu desarrollo.

    7.3.- En todos los esquemas de lectura Pydantic (Read) se crea la subclase 
        model_config = {
            "from_attributes": True  
        }

        Esta definición hay que remplazarla por la siguiente si estas utilizando pydantic 2.0 o superior:
            
        model_config = {
            "from_attributes": True  
        }

             Ya a partir de pydantic 2.0 o superior se ha cambiado la subclase por la propiedad mencionada.

9) Clase CRUD para facilitar las consultas.    
    El proyecto incluye una clase CRUDBase en el archivo crud.py incluido en la carpeta 'services', esta clase encapsula las operaciones comunes de base de datos (CRUD) para todos tus modelos en SQLAlchemy. Su propósito es evitar repetir código en cada clase CRUD específica.

    La utilizaremos como plantilla genérica para todas tus operaciones de base de datos. Una vez definida, puedes usarla para cualquier modelo sin tener que reescribir create, get, update, etc.

    ¿Como utilizarla?
    from models import m_mxproyecto  # Modelo de la base de datos
    from schemas import * # Importa los esquemas Pydantic
    from services.crud import CRUDBase #Los Servicios CRUD

    crud_Accounts = CRUDBase[m_mxproyecto.Accounts, AccountsCreate, AccountsUpdate, AccountsRead](model=m_mxproyecto.Accounts, read_schema=AccountsRead, 
    pk_field="idAccount")

    Nota: Es importante saber que si vas a utilizar el metodo 'create', y tus IDs no son autoincrementables (IDENTITY), en tus modelos en los campos definidos como 'primary_key',  agregues la propiedad 'autoincrement=False' para que SQL Alchemy no lo tome como SET IDENTITY_INSERT ... ON y puedas agregar IDs manualmente.  

    Ejemplo: 
        idAccount = Column(Integer, primary_key=True, autoincrement=False)
        
    Ya con esto estas preparado para consumir el modelo de datos de tu proyecto de una manera mas agil.
                       
