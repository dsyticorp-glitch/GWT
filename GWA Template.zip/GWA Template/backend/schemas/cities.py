from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class CitiesBase(BaseModel):
    idCity: int
    idState: int
    name: Optional[str]
    status: Optional[bool]

class CitiesCreate(CitiesBase):
    pass

class CitiesUpdate(BaseModel):
    idCity: int
    idState: int
    name: Optional[str]
    status: Optional[bool]

class CitiesRead(CitiesBase):
    model_config = {
            "from_attributes": True  
        }
