from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class OptionsBase(BaseModel):
    idOption: int
    value: Optional[str]
    status: Optional[bool]

class OptionsCreate(OptionsBase):
    pass

class OptionsUpdate(BaseModel):
    idOption: int
    value: Optional[str]
    status: Optional[bool]

class OptionsRead(OptionsBase):
    model_config = {
            "from_attributes": True  
        }
