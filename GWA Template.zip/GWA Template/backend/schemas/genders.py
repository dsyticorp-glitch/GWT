from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class GendersBase(BaseModel):
    idGender: int
    name: Optional[str]
    status: Optional[bool]

class GendersCreate(GendersBase):
    pass

class GendersUpdate(BaseModel):
    idGender: int
    name: Optional[str]
    status: Optional[bool]

class GendersRead(GendersBase):
    model_config = {
            "from_attributes": True  
        }
