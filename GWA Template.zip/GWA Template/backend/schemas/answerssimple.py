from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class AnswersSimpleBase(BaseModel):
    idAnswer: int
    idQuestion: int
    idQuiz: int
    idRespondent: int
    idOla: int
    date: Optional[date]
    answer: Optional[str]
    status: Optional[bool]

class AnswersSimpleCreate(AnswersSimpleBase):
    pass

class AnswersSimpleUpdate(BaseModel):
    idAnswer: int
    idQuestion: int
    idQuiz: int
    idRespondent: int
    idOla: int
    date: Optional[date]
    answer: Optional[str]
    status: Optional[bool]

class AnswersSimpleRead(AnswersSimpleBase):
    model_config = {
            "from_attributes": True  
        }
