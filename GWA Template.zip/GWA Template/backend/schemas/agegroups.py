from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class AgegroupsBase(BaseModel):
    idAgegroup: int
    name: Optional[str]
    status: Optional[bool]

class AgegroupsCreate(AgegroupsBase):
    pass

class AgegroupsUpdate(BaseModel):
    idAgegroup: int
    name: Optional[str]
    status: Optional[bool]

class AgegroupsRead(AgegroupsBase):
    model_config = {
            "from_attributes": True  
        }
