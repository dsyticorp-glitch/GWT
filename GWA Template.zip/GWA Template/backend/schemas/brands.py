from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class BrandsBase(BaseModel):
    idBrand: int
    name: Optional[str]
    status: Optional[bool]

class BrandsCreate(BrandsBase):
    pass

class BrandsUpdate(BaseModel):
    idBrand: int
    name: Optional[str]
    status: Optional[bool]

class BrandsRead(BrandsBase):
    model_config = {
            "from_attributes": True  
        }
