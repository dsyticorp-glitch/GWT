from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class ProjectsAccountsBase(BaseModel):
    idProject: int
    idAccount: int
    status: Optional[bool]

class ProjectsAccountsCreate(ProjectsAccountsBase):
    pass

class ProjectsAccountsUpdate(BaseModel):
    idProject: int
    idAccount: int
    status: Optional[bool]

class ProjectsAccountsRead(ProjectsAccountsBase):
    model_config = {
            "from_attributes": True  
        }
