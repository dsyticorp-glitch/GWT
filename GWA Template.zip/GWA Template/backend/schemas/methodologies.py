from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class MethodologiesBase(BaseModel):
    idMethodology: int
    name: Optional[str]
    status: Optional[bool]

class MethodologiesCreate(MethodologiesBase):
    pass

class MethodologiesUpdate(BaseModel):
    idMethodology: int
    name: Optional[str]
    status: Optional[bool]

class MethodologiesRead(MethodologiesBase):
    model_config = {
            "from_attributes": True  
        }
