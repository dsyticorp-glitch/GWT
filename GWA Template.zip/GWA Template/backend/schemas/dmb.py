from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class DmbBase(BaseModel):
    idAccount: int
    idBrand: int
    idQuiz: int
    presenceValue: Optional[int]
    tradeValue: Optional[int]
    desirability: Optional[int]

class DmbCreate(DmbBase):
    pass

class DmbUpdate(BaseModel):
    idAccount: int
    idBrand: int
    idQuiz: int
    presenceValue: Optional[int]
    tradeValue: Optional[int]
    desirability: Optional[int]

class DmbRead(DmbBase):
    model_config = {
            "from_attributes": True  
        }
