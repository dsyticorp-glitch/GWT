from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class AnswersOptionsBase(BaseModel):
    idAnswer: int
    idQuestion: int
    idQuiz: int
    idRespondent: int
    idOla: int
    idOption: int
    date: Optional[date]
    answer: Optional[str]
    status: Optional[bool]

class AnswersOptionsCreate(AnswersOptionsBase):
    pass

class AnswersOptionsUpdate(BaseModel):
    idAnswer: int
    idQuestion: int
    idQuiz: int
    idRespondent: int
    idOla: int
    idOption: int
    date: Optional[date]
    answer: Optional[str]
    status: Optional[bool]

class AnswersOptionsRead(AnswersOptionsBase):
    model_config = {
            "from_attributes": True  
        }
