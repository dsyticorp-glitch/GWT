from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class StatesBase(BaseModel):
    idState: int
    name: Optional[str]
    status: Optional[bool]

class StatesCreate(StatesBase):
    pass

class StatesUpdate(BaseModel):
    idState: int
    name: Optional[str]
    status: Optional[bool]

class StatesRead(StatesBase):
    model_config = {
            "from_attributes": True  
        }
