from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class AccountsBrandsBase(BaseModel):
    idAccount: int
    idBrand: int
    status: Optional[bool]

class AccountsBrandsCreate(AccountsBrandsBase):
    pass

class AccountsBrandsUpdate(BaseModel):
    idAccount: int
    idBrand: int
    status: Optional[bool]

class AccountsBrandsRead(AccountsBrandsBase):
    model_config = {
            "from_attributes": True  
        }
