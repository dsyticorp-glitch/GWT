from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class AccountsBase(BaseModel):
    idAccount: int
    name: Optional[str]
    status: Optional[bool]

class AccountsCreate(AccountsBase):
    pass

class AccountsUpdate(BaseModel):
    idAccount: int
    name: Optional[str]
    status: Optional[bool]

class AccountsRead(AccountsBase):
    model_config = {
            "from_attributes": True  
        }
