from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class ProjectsBase(BaseModel):
    idProject: int
    name: Optional[str]
    description: Optional[str]
    status: Optional[bool]

class ProjectsCreate(ProjectsBase):
    pass

class ProjectsUpdate(BaseModel):
    idProject: int
    name: Optional[str]
    description: Optional[str]
    status: Optional[bool]

class ProjectsRead(ProjectsBase):
    model_config = {
            "from_attributes": True  
        }
