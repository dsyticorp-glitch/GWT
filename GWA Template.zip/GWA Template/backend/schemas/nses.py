from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class NsesBase(BaseModel):
    idNse: int
    name: Optional[str]
    status: Optional[bool]

class NsesCreate(NsesBase):
    pass

class NsesUpdate(BaseModel):
    idNse: int
    name: Optional[str]
    status: Optional[bool]

class NsesRead(NsesBase):
    model_config = {
            "from_attributes": True  
        }
