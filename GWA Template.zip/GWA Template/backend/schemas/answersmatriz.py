from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class AnswersMatrizBase(BaseModel):
    idAnswer: int
    idQuestion: int
    idQuiz: int
    idRespondent: int
    idOla: int
    idRow: int
    idColumn: int
    date: Optional[date]
    answer: Optional[str]
    status: Optional[bool]

class AnswersMatrizCreate(AnswersMatrizBase):
    pass

class AnswersMatrizUpdate(BaseModel):
    idAnswer: int
    idQuestion: int
    idQuiz: int
    idRespondent: int
    idOla: int
    idRow: int
    idColumn: int
    date: Optional[date]
    answer: Optional[str]
    status: Optional[bool]

class AnswersMatrizRead(AnswersMatrizBase):
    model_config = {
            "from_attributes": True  
        }
