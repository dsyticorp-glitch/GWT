from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class QuizziesBase(BaseModel):
    idQuiz: int
    name: Optional[str]
    status: Optional[bool]

class QuizziesCreate(QuizziesBase):
    pass

class QuizziesUpdate(BaseModel):
    idQuiz: int
    name: Optional[str]
    status: Optional[bool]

class QuizziesRead(QuizziesBase):
    model_config = {
            "from_attributes": True  
        }
