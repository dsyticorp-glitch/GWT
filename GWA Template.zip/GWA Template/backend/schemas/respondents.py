from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class RespondentsBase(BaseModel):
    idRespondent: int
    idAge: int
    idGender: int
    idNse: int
    idCity: int
    status: Optional[bool]

class RespondentsCreate(RespondentsBase):
    pass

class RespondentsUpdate(BaseModel):
    idRespondent: int
    idAge: int
    idGender: int
    idNse: int
    idCity: int
    status: Optional[bool]

class RespondentsRead(RespondentsBase):
    model_config = {
            "from_attributes": True  
        }
