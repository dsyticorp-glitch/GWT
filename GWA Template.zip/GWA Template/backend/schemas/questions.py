from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class QuestionsBase(BaseModel):
    idQuestion: int
    idQuiz: int
    idProject: int
    idAccount: int
    question: Optional[str]
    adicional: Optional[str]
    status: Optional[bool]

class QuestionsCreate(QuestionsBase):
    pass

class QuestionsUpdate(BaseModel):
    idQuestion: int
    idQuiz: int
    idProject: int
    idAccount: int
    question: Optional[str]
    adicional: Optional[str]
    status: Optional[bool]

class QuestionsRead(QuestionsBase):
    model_config = {
            "from_attributes": True  
        }
