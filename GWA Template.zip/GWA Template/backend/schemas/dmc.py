from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class DmcBase(BaseModel):
    idAccount: int
    idBrand: int
    idQuiz: int
    reliableValue: Optional[float]
    affordableValue: Optional[float]
    techsavyValue: Optional[float]
    trendyValue: Optional[float]

class DmcCreate(DmcBase):
    pass

class DmcUpdate(BaseModel):
    idAccount: int
    idBrand: int
    idQuiz: int
    reliableValue: Optional[float]
    affordableValue: Optional[float]
    techsavyValue: Optional[float]
    trendyValue: Optional[float]

class DmcRead(DmcBase):
    model_config = {
            "from_attributes": True  
        }
