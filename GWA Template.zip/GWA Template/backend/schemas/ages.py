from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class AgesBase(BaseModel):
    idAge: int
    idAgegroup: int
    status: Optional[bool]

class AgesCreate(AgesBase):
    pass

class AgesUpdate(BaseModel):
    idAge: int
    idAgegroup: int
    status: Optional[bool]

class AgesRead(AgesBase):
    model_config = {
            "from_attributes": True  
        }
