from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class MethsStimsBase(BaseModel):
    idMethodology: int
    idStimulus: int
    status: Optional[bool]

class MethsStimsCreate(MethsStimsBase):
    pass

class MethsStimsUpdate(BaseModel):
    idMethodology: int
    idStimulus: int
    status: Optional[bool]

class MethsStimsRead(MethsStimsBase):
    model_config = {
            "from_attributes": True  
        }
