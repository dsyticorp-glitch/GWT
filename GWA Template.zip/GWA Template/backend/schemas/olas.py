from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class OlasBase(BaseModel):
    idOla: int
    name: Optional[str]
    range: Optional[str]
    status: Optional[bool]

class OlasCreate(OlasBase):
    pass

class OlasUpdate(BaseModel):
    idOla: int
    name: Optional[str]
    range: Optional[str]
    status: Optional[bool]

class OlasRead(OlasBase):
    model_config = {
            "from_attributes": True  
        }
