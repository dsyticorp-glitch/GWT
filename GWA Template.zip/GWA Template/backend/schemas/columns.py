from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class ColumnsBase(BaseModel):
    idColumn: int
    value: Optional[str]
    status: Optional[bool]

class ColumnsCreate(ColumnsBase):
    pass

class ColumnsUpdate(BaseModel):
    idColumn: int
    value: Optional[str]
    status: Optional[bool]

class ColumnsRead(ColumnsBase):
    model_config = {
            "from_attributes": True  
        }
