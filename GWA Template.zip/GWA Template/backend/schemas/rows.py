from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class RowsBase(BaseModel):
    idRow: int
    value: Optional[str]
    status: Optional[bool]

class RowsCreate(RowsBase):
    pass

class RowsUpdate(BaseModel):
    idRow: int
    value: Optional[str]
    status: Optional[bool]

class RowsRead(RowsBase):
    model_config = {
            "from_attributes": True  
        }
