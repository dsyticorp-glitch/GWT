from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class StimulusBase(BaseModel):
    idStimulus: int
    name: Optional[str]
    parameter: Optional[str]
    status: Optional[bool]

class StimulusCreate(StimulusBase):
    pass

class StimulusUpdate(BaseModel):
    idStimulus: int
    name: Optional[str]
    parameter: Optional[str]
    status: Optional[bool]

class StimulusRead(StimulusBase):
    model_config = {
            "from_attributes": True  
        }
