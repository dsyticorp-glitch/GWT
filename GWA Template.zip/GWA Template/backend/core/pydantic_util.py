import os
import inspect
from typing import Optional
from sqlalchemy.orm.properties import ColumnProperty
from sqlalchemy.orm.util import class_mapper

SCHEMA_DIR = "schemas"


TYPE_MAP = {
    "Integer": "int",
    "String": "str",
    "Boolean": "bool",
    "Date": "date",
    "DateTime": "datetime",
    "Float": "float"
}

def get_field_type(column):
    col_type = column.type.__class__.__name__
    return TYPE_MAP.get(col_type, "Any")

def write_schema_file(model):
    model_name = model.__name__
    file_name = os.path.join(SCHEMA_DIR, f"{model_name.lower()}.py")

    mapper = class_mapper(model)
    fields = []

    for prop in mapper.attrs:
        if isinstance(prop, ColumnProperty):
            col = prop.columns[0]
            field_name = prop.key
            field_type = get_field_type(col)
            is_id = field_name.lower().startswith("id")
            is_nullable = col.nullable or col.default is not None or col.autoincrement
            if not is_id and is_nullable:
                field_type = f"Optional[{field_type}]"
            fields.append((field_name, field_type))

    def format_fields(fields, make_optional=False):
        lines = []
        for name, type_ in fields:
            if make_optional and not name.lower().startswith("id"):
                if not type_.startswith("Optional"):
                    type_ = f"Optional[{type_}]"
            lines.append(f"    {name}: {type_}")
        return "\n".join(lines)

    with open(file_name, "w", encoding="utf-8") as f:
        f.write("from pydantic import BaseModel\n")
        f.write("from typing import Optional\n")
        f.write("from datetime import date, datetime\n\n")

        # Base
        f.write(f"class {model_name}Base(BaseModel):\n")
        f.write(format_fields(fields) or "    pass")
        f.write("\n\n")

        # Create
        f.write(f"class {model_name}Create({model_name}Base):\n")
        f.write(" pass\n\n")

        # Update
        f.write(f"class {model_name}Update(BaseModel):\n")
        f.write(format_fields(fields, make_optional=True) or "    pass")
        f.write("\n\n")

        # Read
        f.write(f"class {model_name}Read({model_name}Base):\n")
        f.write("    class Config:\n")
        f.write("    orm_mode = True\n")