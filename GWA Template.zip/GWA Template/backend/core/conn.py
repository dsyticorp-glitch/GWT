from core import AppSettings
import requests

app_settings = AppSettings()

def getConn():   
    try:
        url = "https://data.mx-publicismedia.com/publicisConexion/Conexion/"
        params = {
            "proyecto": app_settings.PROJECT_NAME
        }             
        response = requests.get(url, params=params)
        if response.status_code == 200:
            result = response.json()            
            data = {
                "code":response.status_code,
                "idsgbd": int(result["idsgbd"]),
                "user": result["user"],
                "pwd": result["pwd"],
                "server": result["server"],
                "db": result["db"],
                "status": int(result["status"])
            }            
            return data
    except Exception as e:

        data = {
                "code":401,
                "idsgbd": None,
                "user": None,
                "pwd": None,
                "server": None,
                "db": None,
                "status": None
            }
        return data
   
