# core/middleware.py
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from typing import Callable, Any
from core.logger import logger  
import json

 
class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable) -> Any:
        logger.info(f"Se realizo una petición: {request.method} {request.url.path}")
        
        try:
            response = await call_next(request)            
            logger.info(f"Estado final de la respuesta: {response.status_code}")
            if(response.status_code == 400 or response.status_code == 404):
                body = [section async for section in response.body_iterator]
                #logger.error(f"Detalle: {response.}")                     
            return response
 
        except Exception as e:
            logger.error(f"Error:{e}")
            raise
 
        finally:
            logger.info("Fin del proceso con exito.")