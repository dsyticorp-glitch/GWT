from datetime import datetime
from typing import Any, List, Optional
from fastapi.responses import JSONResponse
from cryptography.fernet import Fernet
import base64

class Encrypt:
    
    # Función para convertir una clave de texto a una clave de 32 bytes en formato base64 URL-safe.
    def clave_a_fernet(clave):
        clave_bytes = clave.encode('utf-8')
        clave_base64 = base64.urlsafe_b64encode(clave_bytes.ljust(32, b'\0')) # Ajustamos a 32 bytes
        return clave_base64

    # Función para encriptar un mensaje
    def encriptar(texto, clave):
        fernet = Fernet(Encrypt.clave_a_fernet(clave))
        mensaje_bytes = texto.encode('utf-8')
        mensaje_encriptado = fernet.encrypt(mensaje_bytes)
        return mensaje_encriptado

    # Función para desencriptar un mensaje
    def desencriptar(texto, clave):
        fernet = Fernet(Encrypt.clave_a_fernet(clave))
        mensaje_desencriptado = fernet.decrypt(texto)
        return mensaje_desencriptado.decode('utf-8')
    

class APIResponse:
    @staticmethod
    def success(data: Any = None, message: str = "Operación exitosa",  status_code: int = 200) -> JSONResponse:
        return JSONResponse(
            status_code=status_code,
            content={
                "message": message,
                "data": data,
                "errors": None,
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        )

    @staticmethod
    def error(message: str = "Ocurrió un error", errors: Optional[List[str]] = None, status_code: int = 400) -> JSONResponse:
        return JSONResponse(
            status_code=status_code,
            content={
                "message": message,
                "data": None,
                "errors": errors,
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        )