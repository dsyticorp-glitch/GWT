from pydantic_settings import BaseSettings
from pathlib import Path

class AppSettings(BaseSettings):
  
    PROJECT_NAME: str = ""
    
    class Config: #Config para AppSettings, clase definida por la libreria de pydantic-settings 
        env_file = "pub.env"
        env_file_encoding = "utf-8"
  
def get_app_settings():  #Funcion que retorna la instancia de las clase de AppSettings.
    return AppSettings() #Retornamos una instancia de AppSettings
