# core/logger.py
import logging
from logging.handlers import RotatingFileHandler
import os
 
log_dir = os.path.dirname(os.path.abspath(__file__))  # Ruta del archivo actual
data_path = os.path.dirname(log_dir)# Retroceso de un nivel
log_file_path = os.path.join(data_path,"app.log")# Agregando un nivel
        
logger = logging.getLogger("app_logger")
logger.setLevel(logging.INFO)
 
# Verifica handlers duplicados
if not any(isinstance(h, RotatingFileHandler) and h.baseFilename == log_file_path for h in logger.handlers):
    handler = RotatingFileHandler(log_file_path, maxBytes=5_000_000, backupCount=3)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
 
# Opcional: evitar duplicar también consola
if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)