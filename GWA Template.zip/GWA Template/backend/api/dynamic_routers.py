from services.wslist import routers

def dinamic_routers(app):
    for router in routers:
        app.include_router(router)
        print(f"✅ Router '{router.prefix}' incluido.")