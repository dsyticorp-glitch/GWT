from fastapi import FastAPI
from core import middleware
from api.dynamic_routers import dinamic_routers

app = FastAPI()
app.title = "BLI"

app.add_middleware(middleware.LoggingMiddleware)

dinamic_routers(app)
