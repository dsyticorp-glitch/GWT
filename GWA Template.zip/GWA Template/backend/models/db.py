from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from core import conn
from cachetools import TTLCache
from typing import Dict

mem_cache = TTLCache(maxsize=10, ttl=86400)
 
class Connection:
    
    def get_data_conexion():
        
        if "conexion" in mem_cache:
            return mem_cache["conexion"]
        
        else:        
            data = conn.getConn()            
            
            code = int(data["code"])
            idsgbd = data["idsgbd"]
            user = data["user"]
            pwd = data["pwd"]
            server = data["server"]
            db = data["db"]
            status = int(data["status"])
            
            mem_cache["conexion"] = {"code": code, "idsgbd": idsgbd, "user": user, "pwd": pwd, "server": server, "db": db, "status": status}
        
        return mem_cache["conexion"]        
   
    conex = get_data_conexion()
    
    if conex["code"] == 200:        
        if conex["status"] == 1:
            if conex["idsgbd"] == 1:
                SQLALCHEMY_DATABASE_URL = f"mssql+pyodbc://{conex["user"]}:{conex["pwd"]}@{conex["server"]}/{conex["db"]}?driver=ODBC+Driver+17+for+SQL+Server"
    engine = create_engine(SQLALCHEMY_DATABASE_URL, pool_pre_ping=True)#Creando el motor de conexión
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)#Creando la sesión de la base de datos
    Base = declarative_base()#Declarative base para SQLAlchemy