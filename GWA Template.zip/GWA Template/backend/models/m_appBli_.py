from typing import List, Optional

from sqlalchemy import Boolean, Date, Float, ForeignKeyConstraint, Identity, Integer, PrimaryKeyConstraint, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
import datetime

class Base(DeclarativeBase):
    pass


class Accounts(Base):
    __tablename__ = 'accounts'
    __table_args__ = (
        PrimaryKeyConstraint('idAccount', name='PK_accounts'),
        {'schema': 'dbo'}
    )

    idAccount: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    accounts_brands: Mapped[List['AccountsBrands']] = relationship('AccountsBrands', back_populates='accounts')
    projects_accounts: Mapped[List['ProjectsAccounts']] = relationship('ProjectsAccounts', back_populates='accounts')


class Agegroups(Base):
    __tablename__ = 'agegroups'
    __table_args__ = (
        PrimaryKeyConstraint('idAgegroup', name='PK_agegroups'),
        {'schema': 'dbo'}
    )

    idAgegroup: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    ages: Mapped[List['Ages']] = relationship('Ages', back_populates='agegroups')


class Brands(Base):
    __tablename__ = 'brands'
    __table_args__ = (
        PrimaryKeyConstraint('idBrand', name='PK_brands'),
        {'schema': 'dbo'}
    )

    idBrand: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    accounts_brands: Mapped[List['AccountsBrands']] = relationship('AccountsBrands', back_populates='brands')


class Columns(Base):
    __tablename__ = 'columns'
    __table_args__ = (
        PrimaryKeyConstraint('idColumn', name='PK_columns'),
        {'schema': 'dbo'}
    )

    idColumn: Mapped[int] = mapped_column(Integer, primary_key=True)
    value: Mapped[Optional[str]] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    answers_matriz: Mapped[List['AnswersMatriz']] = relationship('AnswersMatriz', back_populates='columns')


class Genders(Base):
    __tablename__ = 'genders'
    __table_args__ = (
        PrimaryKeyConstraint('idGender', name='PK_genders'),
        {'schema': 'dbo'}
    )

    idGender: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    respondents: Mapped[List['Respondents']] = relationship('Respondents', back_populates='genders')


class Methodologies(Base):
    __tablename__ = 'methodologies'
    __table_args__ = (
        PrimaryKeyConstraint('idMethodology', name='PK_methodologies'),
        {'schema': 'dbo'}
    )

    idMethodology: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(50, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    meths_stims: Mapped[List['MethsStims']] = relationship('MethsStims', back_populates='methodologies')


class Nses(Base):
    __tablename__ = 'nses'
    __table_args__ = (
        PrimaryKeyConstraint('idNse', name='PK_nses'),
        {'schema': 'dbo'}
    )

    idNse: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    respondents: Mapped[List['Respondents']] = relationship('Respondents', back_populates='nses')


class Olas(Base):
    __tablename__ = 'olas'
    __table_args__ = (
        PrimaryKeyConstraint('idOla', name='PK_ola'),
        {'schema': 'dbo'}
    )

    idOla: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    range: Mapped[str] = mapped_column(String(50, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    answers_matriz: Mapped[List['AnswersMatriz']] = relationship('AnswersMatriz', back_populates='olas')
    answers_options: Mapped[List['AnswersOptions']] = relationship('AnswersOptions', back_populates='olas')
    answers_simple: Mapped[List['AnswersSimple']] = relationship('AnswersSimple', back_populates='olas')


class Options(Base):
    __tablename__ = 'options'
    __table_args__ = (
        PrimaryKeyConstraint('idOption', name='PK_options'),
        {'schema': 'dbo'}
    )

    idOption: Mapped[int] = mapped_column(Integer, primary_key=True)
    value: Mapped[str] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    answers_options: Mapped[List['AnswersOptions']] = relationship('AnswersOptions', back_populates='options')


class Projects(Base):
    __tablename__ = 'projects'
    __table_args__ = (
        PrimaryKeyConstraint('idProject', name='PK_projects'),
        {'schema': 'dbo'}
    )

    idProject: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    description: Mapped[str] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    projects_accounts: Mapped[List['ProjectsAccounts']] = relationship('ProjectsAccounts', back_populates='projects')


class Quizzies(Base):
    __tablename__ = 'quizzies'
    __table_args__ = (
        PrimaryKeyConstraint('idQuiz', name='PK_quizzes'),
        {'schema': 'dbo'}
    )

    idQuiz: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    dmb: Mapped[List['Dmb']] = relationship('Dmb', back_populates='quizzies')
    dmc: Mapped[List['Dmc']] = relationship('Dmc', back_populates='quizzies')


class Rows(Base):
    __tablename__ = 'rows'
    __table_args__ = (
        PrimaryKeyConstraint('idRow', name='PK_rows'),
        {'schema': 'dbo'}
    )

    idRow: Mapped[int] = mapped_column(Integer, primary_key=True)
    value: Mapped[Optional[str]] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    answers_matriz: Mapped[List['AnswersMatriz']] = relationship('AnswersMatriz', back_populates='rows')


class States(Base):
    __tablename__ = 'states'
    __table_args__ = (
        PrimaryKeyConstraint('idState', name='PK_states'),
        {'schema': 'dbo'}
    )

    idState: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    cities: Mapped[List['Cities']] = relationship('Cities', back_populates='states')


class Stimulus(Base):
    __tablename__ = 'stimulus'
    __table_args__ = (
        PrimaryKeyConstraint('idStimulus', name='PK_stimulus'),
        {'schema': 'dbo'}
    )

    idStimulus: Mapped[int] = mapped_column(Integer, Identity(start=0, increment=1), primary_key=True)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    parameter: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    meths_stims: Mapped[List['MethsStims']] = relationship('MethsStims', back_populates='stimulus')


class AccountsBrands(Base):
    __tablename__ = 'accounts_brands'
    __table_args__ = (
        ForeignKeyConstraint(['idAccount'], ['dbo.accounts.idAccount'], name='FK_accounts_brands_accounts'),
        ForeignKeyConstraint(['idBrand'], ['dbo.brands.idBrand'], name='FK_accounts_brands_brands'),
        PrimaryKeyConstraint('idAccount', 'idBrand', name='PK_accounts_brands'),
        {'schema': 'dbo'}
    )

    idAccount: Mapped[int] = mapped_column(Integer, primary_key=True)
    idBrand: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    accounts: Mapped['Accounts'] = relationship('Accounts', back_populates='accounts_brands')
    brands: Mapped['Brands'] = relationship('Brands', back_populates='accounts_brands')
    dmb: Mapped[List['Dmb']] = relationship('Dmb', back_populates='accounts_brands')
    dmc: Mapped[List['Dmc']] = relationship('Dmc', back_populates='accounts_brands')


class Ages(Base):
    __tablename__ = 'ages'
    __table_args__ = (
        ForeignKeyConstraint(['idAgegroup'], ['dbo.agegroups.idAgegroup'], name='FK_ages_agegroups'),
        PrimaryKeyConstraint('idAge', name='PK_ages'),
        {'schema': 'dbo'}
    )

    idAge: Mapped[int] = mapped_column(Integer, primary_key=True)
    idAgegroup: Mapped[int] = mapped_column(Integer)
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    agegroups: Mapped['Agegroups'] = relationship('Agegroups', back_populates='ages')
    respondents: Mapped[List['Respondents']] = relationship('Respondents', back_populates='ages')


class Cities(Base):
    __tablename__ = 'cities'
    __table_args__ = (
        ForeignKeyConstraint(['idState'], ['dbo.states.idState'], name='FK_cities_states'),
        PrimaryKeyConstraint('idCity', name='PK_cities'),
        {'schema': 'dbo'}
    )

    idCity: Mapped[int] = mapped_column(Integer, primary_key=True)
    idState: Mapped[int] = mapped_column(Integer)
    name: Mapped[str] = mapped_column(String(100, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    states: Mapped['States'] = relationship('States', back_populates='cities')
    respondents: Mapped[List['Respondents']] = relationship('Respondents', back_populates='cities')


class MethsStims(Base):
    __tablename__ = 'meths_stims'
    __table_args__ = (
        ForeignKeyConstraint(['idMethodology'], ['dbo.methodologies.idMethodology'], name='FK_meths_stims_methodologies'),
        ForeignKeyConstraint(['idStimulus'], ['dbo.stimulus.idStimulus'], name='FK_meths_stims_stimulus'),
        PrimaryKeyConstraint('idMethodology', 'idStimulus', name='PK_meths_stims'),
        {'schema': 'dbo'}
    )

    idMethodology: Mapped[int] = mapped_column(Integer, primary_key=True)
    idStimulus: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    methodologies: Mapped['Methodologies'] = relationship('Methodologies', back_populates='meths_stims')
    stimulus: Mapped['Stimulus'] = relationship('Stimulus', back_populates='meths_stims')


class ProjectsAccounts(Base):
    __tablename__ = 'projects_accounts'
    __table_args__ = (
        ForeignKeyConstraint(['idAccount'], ['dbo.accounts.idAccount'], name='FK_projects_accounts_accounts'),
        ForeignKeyConstraint(['idProject'], ['dbo.projects.idProject'], name='FK_projects_accounts_projects'),
        PrimaryKeyConstraint('idProject', 'idAccount', name='PK_projects_accounts'),
        {'schema': 'dbo'}
    )

    idProject: Mapped[int] = mapped_column(Integer, primary_key=True)
    idAccount: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    accounts: Mapped['Accounts'] = relationship('Accounts', back_populates='projects_accounts')
    projects: Mapped['Projects'] = relationship('Projects', back_populates='projects_accounts')
    questions: Mapped[List['Questions']] = relationship('Questions', back_populates='projects_accounts')


class Dmb(Base):
    __tablename__ = 'dmb'
    __table_args__ = (
        ForeignKeyConstraint(['idAccount', 'idBrand'], ['dbo.accounts_brands.idAccount', 'dbo.accounts_brands.idBrand'], name='FK_dmb_accounts_brands'),
        ForeignKeyConstraint(['idQuiz'], ['dbo.quizzies.idQuiz'], name='FK_dmb_quiz'),
        PrimaryKeyConstraint('idAccount', 'idBrand', 'idQuiz', name='PK_dmb'),
        {'schema': 'dbo'}
    )

    idAccount: Mapped[int] = mapped_column(Integer, primary_key=True)
    idBrand: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuiz: Mapped[int] = mapped_column(Integer, primary_key=True)
    presenceValue: Mapped[int] = mapped_column(Integer)
    tradeValue: Mapped[int] = mapped_column(Integer)
    desirability: Mapped[int] = mapped_column(Integer)

    accounts_brands: Mapped['AccountsBrands'] = relationship('AccountsBrands', back_populates='dmb')
    quizzies: Mapped['Quizzies'] = relationship('Quizzies', back_populates='dmb')


class Dmc(Base):
    __tablename__ = 'dmc'
    __table_args__ = (
        ForeignKeyConstraint(['idAccount', 'idBrand'], ['dbo.accounts_brands.idAccount', 'dbo.accounts_brands.idBrand'], name='FK_dmc_accounts_brands'),
        ForeignKeyConstraint(['idQuiz'], ['dbo.quizzies.idQuiz'], name='FK_dmc_quiz'),
        PrimaryKeyConstraint('idAccount', 'idBrand', 'idQuiz', name='PK_dmc'),
        {'schema': 'dbo'}
    )

    idAccount: Mapped[int] = mapped_column(Integer, primary_key=True)
    idBrand: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuiz: Mapped[int] = mapped_column(Integer, primary_key=True)
    reliableValue: Mapped[float] = mapped_column(Float(53))
    affordableValue: Mapped[float] = mapped_column(Float(53))
    techsavyValue: Mapped[float] = mapped_column(Float(53))
    trendyValue: Mapped[float] = mapped_column(Float(53))

    accounts_brands: Mapped['AccountsBrands'] = relationship('AccountsBrands', back_populates='dmc')
    quizzies: Mapped['Quizzies'] = relationship('Quizzies', back_populates='dmc')


class Questions(Base):
    __tablename__ = 'questions'
    __table_args__ = (
        ForeignKeyConstraint(['idProject', 'idAccount'], ['dbo.projects_accounts.idProject', 'dbo.projects_accounts.idAccount'], name='FK_questions_projects_accounts'),
        PrimaryKeyConstraint('idQuestion', 'idQuiz', name='PK_questions'),
        {'schema': 'dbo'}
    )

    idQuestion: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuiz: Mapped[int] = mapped_column(Integer, primary_key=True)
    idProject: Mapped[int] = mapped_column(Integer)
    idAccount: Mapped[int] = mapped_column(Integer)
    question: Mapped[str] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    adicional: Mapped[str] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    projects_accounts: Mapped['ProjectsAccounts'] = relationship('ProjectsAccounts', back_populates='questions')
    answers_matriz: Mapped[List['AnswersMatriz']] = relationship('AnswersMatriz', back_populates='questions')
    answers_options: Mapped[List['AnswersOptions']] = relationship('AnswersOptions', back_populates='questions')
    answers_simple: Mapped[List['AnswersSimple']] = relationship('AnswersSimple', back_populates='questions')


class Respondents(Base):
    __tablename__ = 'respondents'
    __table_args__ = (
        ForeignKeyConstraint(['idAge'], ['dbo.ages.idAge'], name='FK_respondents_ages'),
        ForeignKeyConstraint(['idCity'], ['dbo.cities.idCity'], name='FK_respondents_cities'),
        ForeignKeyConstraint(['idGender'], ['dbo.genders.idGender'], name='FK_respondents_genders'),
        ForeignKeyConstraint(['idNse'], ['dbo.nses.idNse'], name='FK_respondents_nses'),
        PrimaryKeyConstraint('idRespondent', name='PK_respondents'),
        {'schema': 'dbo'}
    )

    idRespondent: Mapped[int] = mapped_column(Integer, primary_key=True)
    idAge: Mapped[int] = mapped_column(Integer)
    idGender: Mapped[int] = mapped_column(Integer)
    idNse: Mapped[int] = mapped_column(Integer)
    idCity: Mapped[int] = mapped_column(Integer)
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    ages: Mapped['Ages'] = relationship('Ages', back_populates='respondents')
    cities: Mapped['Cities'] = relationship('Cities', back_populates='respondents')
    genders: Mapped['Genders'] = relationship('Genders', back_populates='respondents')
    nses: Mapped['Nses'] = relationship('Nses', back_populates='respondents')
    answers_matriz: Mapped[List['AnswersMatriz']] = relationship('AnswersMatriz', back_populates='respondents')
    answers_options: Mapped[List['AnswersOptions']] = relationship('AnswersOptions', back_populates='respondents')
    answers_simple: Mapped[List['AnswersSimple']] = relationship('AnswersSimple', back_populates='respondents')


class AnswersMatriz(Base):
    __tablename__ = 'answers_matriz'
    __table_args__ = (
        ForeignKeyConstraint(['idColumn'], ['dbo.columns.idColumn'], name='FK_answers_matriz_columns'),
        ForeignKeyConstraint(['idOla'], ['dbo.olas.idOla'], name='FK_answers_matriz_olas'),
        ForeignKeyConstraint(['idQuestion', 'idQuiz'], ['dbo.questions.idQuestion', 'dbo.questions.idQuiz'], name='FK_answers_matriz_questions'),
        ForeignKeyConstraint(['idRespondent'], ['dbo.respondents.idRespondent'], name='FK_answers_matriz_respondents'),
        ForeignKeyConstraint(['idRow'], ['dbo.rows.idRow'], name='FK_answers_matriz_rows'),
        PrimaryKeyConstraint('idAnswer', 'idQuestion', 'idQuiz', 'idRespondent', name='PK_answers_matriz'),
        {'schema': 'dbo'}
    )

    idAnswer: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuestion: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuiz: Mapped[int] = mapped_column(Integer, primary_key=True)
    idRespondent: Mapped[int] = mapped_column(Integer, primary_key=True)
    idOla: Mapped[int] = mapped_column(Integer)
    idRow: Mapped[int] = mapped_column(Integer)
    idColumn: Mapped[int] = mapped_column(Integer)
    date: Mapped[datetime.date] = mapped_column(Date)
    answer: Mapped[Optional[str]] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    columns: Mapped['Columns'] = relationship('Columns', back_populates='answers_matriz')
    olas: Mapped['Olas'] = relationship('Olas', back_populates='answers_matriz')
    questions: Mapped['Questions'] = relationship('Questions', back_populates='answers_matriz')
    respondents: Mapped['Respondents'] = relationship('Respondents', back_populates='answers_matriz')
    rows: Mapped['Rows'] = relationship('Rows', back_populates='answers_matriz')


class AnswersOptions(Base):
    __tablename__ = 'answers_options'
    __table_args__ = (
        ForeignKeyConstraint(['idOla'], ['dbo.olas.idOla'], name='FK_answers_options_olas'),
        ForeignKeyConstraint(['idOption'], ['dbo.options.idOption'], name='FK_Answers_choice_options'),
        ForeignKeyConstraint(['idQuestion', 'idQuiz'], ['dbo.questions.idQuestion', 'dbo.questions.idQuiz'], name='FK_answers_options_questions'),
        ForeignKeyConstraint(['idRespondent'], ['dbo.respondents.idRespondent'], name='FK_answers_options_respondents'),
        PrimaryKeyConstraint('idAnswer', 'idQuestion', 'idQuiz', 'idRespondent', name='PK_answers_options'),
        {'schema': 'dbo'}
    )

    idAnswer: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuestion: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuiz: Mapped[int] = mapped_column(Integer, primary_key=True)
    idRespondent: Mapped[int] = mapped_column(Integer, primary_key=True)
    idOla: Mapped[int] = mapped_column(Integer)
    idOption: Mapped[int] = mapped_column(Integer)
    date: Mapped[datetime.date] = mapped_column(Date)
    answer: Mapped[Optional[str]] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    olas: Mapped['Olas'] = relationship('Olas', back_populates='answers_options')
    options: Mapped['Options'] = relationship('Options', back_populates='answers_options')
    questions: Mapped['Questions'] = relationship('Questions', back_populates='answers_options')
    respondents: Mapped['Respondents'] = relationship('Respondents', back_populates='answers_options')


class AnswersSimple(Base):
    __tablename__ = 'answers_simple'
    __table_args__ = (
        ForeignKeyConstraint(['idOla'], ['dbo.olas.idOla'], name='FK_answers_simple_olas'),
        ForeignKeyConstraint(['idQuestion', 'idQuiz'], ['dbo.questions.idQuestion', 'dbo.questions.idQuiz'], name='FK_answers_simple_questions'),
        ForeignKeyConstraint(['idRespondent'], ['dbo.respondents.idRespondent'], name='FK_answers_simple_respondents'),
        PrimaryKeyConstraint('idAnswer', 'idQuestion', 'idQuiz', 'idRespondent', name='PK_answers_simple'),
        {'schema': 'dbo'}
    )

    idAnswer: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuestion: Mapped[int] = mapped_column(Integer, primary_key=True)
    idQuiz: Mapped[int] = mapped_column(Integer, primary_key=True)
    idRespondent: Mapped[int] = mapped_column(Integer, primary_key=True)
    idOla: Mapped[int] = mapped_column(Integer)
    date: Mapped[datetime.date] = mapped_column(Date)
    answer: Mapped[Optional[str]] = mapped_column(String(200, 'SQL_Latin1_General_CP1_CI_AS'))
    status: Mapped[Optional[bool]] = mapped_column(Boolean)

    olas: Mapped['Olas'] = relationship('Olas', back_populates='answers_simple')
    questions: Mapped['Questions'] = relationship('Questions', back_populates='answers_simple')
    respondents: Mapped['Respondents'] = relationship('Respondents', back_populates='answers_simple')
