const miApp = {
    data() {
        return {
          newTask: "",
          tasks: [
            { name: "Aprender Vue.js", done: true },
            { name: "Crear una app con CDN", done: false }
          ]
        };
      },
      computed: {
        totalTasks() {
          return this.tasks.length;
        },
        completedTasks() {
          return this.tasks.filter(task => task.done).length;
        }
      },
      methods: {
        addTask() {
          const text = this.newTask.trim();
          if (text.length < 3) {
            alert("La tarea debe tener al menos 3 caracteres");
            return;
          }
          this.tasks.push({ name: text, done: false });
          this.newTask = "";
        },
        removeTask(index) {
          this.tasks.splice(index, 1);
        },
        toggleDone(task) {
          task.done = !task.done;
        }
      }
    }

    var app = Vue.createApp(miApp).mount("#app")